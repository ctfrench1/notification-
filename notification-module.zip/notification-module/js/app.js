//Module
var notifications = angular.module('notifications',['ui.bootstrap','ng-animate']);

